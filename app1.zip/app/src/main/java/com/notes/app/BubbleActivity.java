package com.notes.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import android.content.SharedPreferences;

public class BubbleActivity extends Activity {

    private BubbleView bubbleView;
    private List<NoteItem> allNotes = new ArrayList<>();
    private SharedPreferences prefs;
    private long currentFolderId = -1;

    // Палитра цветов для пузырьков
    private static final int[] COLORS = {
        0xFFFFFFFF, // белый
        0xFFFFF9C4, // жёлтый
        0xFFE8F5E9, // зелёный
        0xFFE3F2FD, // голубой
        0xFFFCE4EC, // розовый
        0xFFEDE7F6, // фиолетовый
        0xFFFFE0B2, // оранжевый
        0xFFCFD8DC, // серый
        0xFF80CBC4, // бирюзовый
        0xFFF48FB1, // насыщенный розовый
        0xFF90CAF9, // насыщенный голубой
        0xFFA5D6A7, // насыщенный зелёный
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bubble);

        prefs = getSharedPreferences("notes_prefs", MODE_PRIVATE);
        currentFolderId = getIntent().getLongExtra("open_folder_id", -1);

        loadData();

        bubbleView = new BubbleView(this, allNotes, new BubbleView.Listener() {
            @Override
            public void onTap(NoteItem n) {
                if (n.isFolder) {
                    currentFolderId = n.id;
                    updateUI();
                } else {
                    Intent intent = new Intent(BubbleActivity.this, NoteEditorActivity.class);
                    intent.putExtra("note_id", n.id);
                    startActivity(intent);
                }
            }

            @Override
            public void onDragEnd(long id, float x, float y) {
                prefs.edit()
                    .putFloat("bubble_x_" + id, x)
                    .putFloat("bubble_y_" + id, y)
                    .apply();
            }

            @Override
            public void onMerge(NoteItem dragged, NoteItem target) {
                if (target.isFolder) {
                    prefs.edit().putLong("parentId_" + dragged.id, target.id).apply();
                    loadData();
                    updateUI();
                } else {
                    showCreateFolderDialog(dragged, target);
                }
            }

            @Override
            public void onLongPress(NoteItem n) {
                // ✅ Меню действий при долгом удержании
                showBubbleActionMenu(n);
            }
        });

        // Вставка BubbleView вместо placeholder
        View placeholder = findViewById(R.id.bubbleView);
        if (placeholder != null) {
            ViewGroup parent = (ViewGroup) placeholder.getParent();
            int index = parent.indexOfChild(placeholder);
            parent.removeView(placeholder);
            bubbleView.setId(R.id.bubbleView);
            parent.addView(bubbleView, index);
        } else {
            ((ViewGroup) findViewById(android.R.id.content)).addView(bubbleView);
        }

        updateUI();

        View btnClose = findViewById(R.id.btnBubbleClose);
        if (btnClose != null) {
            btnClose.setOnClickListener(v -> {
                if (currentFolderId != -1) {
                    currentFolderId = -1;
                    updateUI();
                } else {
                    finish();
                }
            });
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Меню долгого удержания пузырька
    // ─────────────────────────────────────────────────────────────
    private void showBubbleActionMenu(NoteItem n) {
        boolean isPinned = prefs.getBoolean("pinned_" + n.id, false);
        String pinLabel = isPinned ? "📌 Открепить" : "📌 Закрепить";

        String[] options = { pinLabel, "🎨 Изменить цвет" };

        new AlertDialog.Builder(this)
            .setTitle(n.title.isEmpty() ? "Действие" : n.title)
            .setItems(options, (dialog, which) -> {
                switch (which) {
                    case 0: // Закрепить / Открепить
                        togglePin(n, isPinned);
                        break;
                    case 1: // Изменить цвет
                        showColorPicker(n);
                        break;
                }
            })
            .show();
    }

    // Переключение закрепления
    private void togglePin(NoteItem n, boolean wasPinned) {
        prefs.edit().putBoolean("pinned_" + n.id, !wasPinned).apply();
        String msg = wasPinned ? "Заметка откреплена" : "Заметка закреплена";
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        loadData();
        updateUI();
    }

    // Выбор цвета — меняет цвет и заметки, и пузырька одновременно
    private void showColorPicker(NoteItem n) {
        GridLayout grid = new GridLayout(this);
        int cols = 4;
        grid.setColumnCount(cols);
        int dp = (int) (getResources().getDisplayMetrics().density);

        for (int color : COLORS) {
            View swatch = new View(this);
            int size = 56 * dp;
            int margin = 6 * dp;
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = size;
            lp.height = size;
            lp.setMargins(margin, margin, margin, margin);
            swatch.setLayoutParams(lp);
            swatch.setBackgroundColor(color);

            // Скруглённые уголки у цветового квадрата
            android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
            gd.setColor(color);
            gd.setCornerRadius(14 * dp);
            gd.setStroke(2 * dp, Color.parseColor("#CCCCCC"));
            swatch.setBackground(gd);

            final int chosenColor = color;
            swatch.setOnClickListener(v -> {
                // Применяем к заметке и к пузырьку (allNotes содержит тот же объект)
                n.color = chosenColor;
                prefs.edit().putInt("color_" + n.id, chosenColor).apply();
                bubbleView.invalidate();
                // Закрываем диалог (он хранится в tag)
                AlertDialog dlg = (AlertDialog) v.getTag();
                if (dlg != null) dlg.dismiss();
            });

            grid.addView(swatch);
        }

        // Добавляем padding к гриду
        int pad = 16 * dp;
        grid.setPadding(pad, pad, pad, pad);

        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("Выберите цвет")
            .setView(grid)
            .setNegativeButton("Отмена", null)
            .create();

        // Передаём ссылку на диалог в каждый swatch через tag
        for (int i = 0; i < grid.getChildCount(); i++) {
            grid.getChildAt(i).setTag(dialog);
        }

        dialog.show();
    }

    // ─────────────────────────────────────────────────────────────
    // Создание папки при слиянии двух обычных пузырьков
    // ─────────────────────────────────────────────────────────────
    private void showCreateFolderDialog(NoteItem n1, NoteItem n2) {
        final EditText input = new EditText(this);
        input.setHint("Название группы");
        new AlertDialog.Builder(this)
            .setTitle("Объединить в группу?")
            .setView(input)
            .setPositiveButton("Создать", (d, w) -> {
                String name = input.getText().toString().trim();
                long fId = System.currentTimeMillis();
                String ids = prefs.getString("all_ids", "");
                prefs.edit()
                    .putString("all_ids", (ids.isEmpty() ? "" : ids + ",") + fId)
                    .putString("title_" + fId, name.isEmpty() ? "Группа" : name)
                    .putBoolean("isFolder_" + fId, true)
                    .putInt("color_" + fId, Color.parseColor("#FFCA28"))
                    .putLong("parentId_" + fId, currentFolderId)
                    .putLong("parentId_" + n1.id, fId)
                    .putLong("parentId_" + n2.id, fId)
                    .apply();
                loadData();
                updateUI();
            })
            .setNegativeButton("Отмена", null)
            .show();
    }

    // ─────────────────────────────────────────────────────────────
    // Жизненный цикл
    // ─────────────────────────────────────────────────────────────
    @Override
    protected void onResume() {
        super.onResume();
        loadData();
        if (bubbleView != null) bubbleView.invalidate();
    }

    // ─────────────────────────────────────────────────────────────
    // Загрузка данных
    // ─────────────────────────────────────────────────────────────
    private void loadData() {
        allNotes.clear();
        String ids = prefs.getString("all_ids", "");
        java.util.Random r = new java.util.Random();
        for (String s : ids.split(",")) {
            if (s.isEmpty()) continue;
            long id = Long.parseLong(s);
            NoteItem item = new NoteItem(
                id,
                prefs.getString("title_" + id, ""),
                prefs.getString("note_" + id, ""),
                prefs.getString("date_" + id, ""),
                prefs.getInt("color_" + id, Color.WHITE)
            );
            item.isFolder  = prefs.getBoolean("isFolder_" + id, false);
            item.isPinned  = prefs.getBoolean("pinned_"  + id, false);
            item.x         = prefs.getFloat("bubble_x_" + id, 300 + r.nextInt(300));
            item.y         = prefs.getFloat("bubble_y_" + id, 500 + r.nextInt(400));
            item.parentId  = prefs.getLong("parentId_"  + id, -1);
            item.scale     = prefs.getFloat("scale_"    + id, 1.0f);
            allNotes.add(item);
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Обновление UI
    // ─────────────────────────────────────────────────────────────
    private void updateUI() {
        if (bubbleView != null) bubbleView.setFolder(currentFolderId);
        TextView tvTitle = findViewById(R.id.tvBubbleTitle);
        if (tvTitle != null) {
            if (currentFolderId == -1) {
                tvTitle.setText("Чертоги разума");
            } else {
                tvTitle.setText(prefs.getString("title_" + currentFolderId, "Группа"));
            }
        }
        // ✅ Синхронизируем цвет фона с темой из MainActivity
        int bgColor = prefs.getInt("theme_bg_color", 0xFFF2F3F7);
        int accentColor = prefs.getInt("theme_accent_color", 0xFF1A1A2E);
        View root = findViewById(android.R.id.content);
        if (root != null) root.setBackgroundColor(bgColor);
        if (tvTitle != null) tvTitle.setTextColor(accentColor);
    }
}