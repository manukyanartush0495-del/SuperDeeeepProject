package com.notes.app;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.*;

public class BubbleView extends View {
    public interface Listener {
        void onTap(NoteItem n);
        void onDragEnd(long id, float x, float y);
        void onMerge(NoteItem dragged, NoteItem target);
        void onLongPress(NoteItem n);
    }

    private List<NoteItem> allNotes;
    private long curFolderId = -1;
    private Listener listener;
    
    private Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint glassHighlightPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    
    private Matrix matrix = new Matrix();
    private float[] mValues = new float[9];
    private ScaleGestureDetector scaleDetector;
    private GestureDetector gestureDetector;
    
    private NoteItem dragNote = null;
    private NoteItem highlightNote = null;
    private float lastX, lastY;

    public BubbleView(Context context, List<NoteItem> notes, Listener l) {
        super(context);
        this.allNotes = notes; 
        this.listener = l;
        
        // Включаем программный слой для корректного отображения теней
        setLayerType(LAYER_TYPE_SOFTWARE, null);

        // Настройка основного текста
        p.setTextAlign(Paint.Align.CENTER);
        p.setFakeBoldText(true);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));

        // Настройка рамки выделения при столкновении
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeWidth(14);
        strokePaint.setColor(Color.WHITE);
        strokePaint.setAlpha(200);

        // Блик для эффекта стекла
        glassHighlightPaint.setStyle(Paint.Style.STROKE);
        glassHighlightPaint.setStrokeWidth(5);
        glassHighlightPaint.setColor(Color.WHITE);
        glassHighlightPaint.setAlpha(100);

        // Детектор масштабирования (зум щипком)
        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {
                matrix.getValues(mValues);
                float curScale = mValues[Matrix.MSCALE_X];
                float factor = detector.getScaleFactor();
                if ((curScale * factor > 4.0f && factor > 1) || (curScale * factor < 0.3f && factor < 1)) return true;
                matrix.postScale(factor, factor, detector.getFocusX(), detector.getFocusY());
                invalidate();
                return true;
            }
        });

        // Детектор жестов (свайпы, тапы, зажатия)
        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                if (dragNote == null) { 
                    matrix.postTranslate(-dx, -dy); 
                    invalidate(); 
                }
                return true;
            }
            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                float[] pts = mapCoords(e.getX(), e.getY());
                for (NoteItem n : getVisibleNotes()) {
                    if (Math.hypot(pts[0] - n.x, pts[1] - n.y) < getRadius(n)) {
                        listener.onTap(n); 
                        return true;
                    }
                }
                return false;
            }
            @Override public void onLongPress(MotionEvent e) {
    float[] pts = mapCoords(e.getX(), e.getY());
    for (NoteItem n : getVisibleNotes()) {
        if (Math.hypot(pts[0] - n.x, pts[1] - n.y) < getRadius(n)) {
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            dragNote = null;        // ← сбрасываем drag, чтобы не тащить после меню
            highlightNote = null;
            listener.onLongPress(n);
            break;
        }
    }
}
        });
    }

    // Динамический радиус (зависит от масштаба заметки и длины текста)
    private float getRadius(NoteItem n) {
        float baseRadius = 130 * n.scale;
        float extraRadius = Math.min(n.title.length() * 1.5f, baseRadius * 0.3f);
        return baseRadius + extraRadius;
    }

    public void setFolder(long id) { 
        this.curFolderId = id; 
        invalidate(); 
    }

    private List<NoteItem> getVisibleNotes() {
        List<NoteItem> visible = new ArrayList<>();
        for (NoteItem n : allNotes) {
            if (n.parentId == curFolderId) visible.add(n);
        }
        return visible;
    }

    private int darkenColor(int color, float factor) {
        int a = Color.alpha(color);
        int r = Math.max(Math.round(Color.red(color) * factor), 0);
        int g = Math.max(Math.round(Color.green(color) * factor), 0);
        int b = Math.max(Math.round(Color.blue(color) * factor), 0);
        return Color.argb(a, r, g, b);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        // Фон прозрачный (чтобы видеть фон Activity)
        canvas.save();
        canvas.concat(matrix);

        for (NoteItem n : getVisibleNotes()) {
            float radius = getRadius(n);

            // Подсветка при наведении шара на шар (Merging UI)
            if (n == highlightNote) {
                canvas.drawCircle(n.x, n.y, radius + 24, strokePaint);
            }

            // 1. Рисуем мягкую тень
            shadowPaint.setColor(n.color);
            shadowPaint.setAlpha(70);
            shadowPaint.setShadowLayer(radius * 0.4f, 0, radius * 0.15f, shadowPaint.getColor());
            canvas.drawCircle(n.x, n.y, radius, shadowPaint);

            // 2. Рисуем основной шар с градиентом объема
            p.clearShadowLayer();
            int darkerColor = darkenColor(n.color, 0.85f);
            p.setShader(new LinearGradient(
                    n.x, n.y - radius, 
                    n.x, n.y + radius, 
                    n.color, darkerColor, 
                    Shader.TileMode.CLAMP));
            canvas.drawCircle(n.x, n.y, radius, p);
            p.setShader(null);

            // 3. Рисуем внутренний блик (стекло)
            canvas.drawCircle(n.x, n.y, radius - 6, glassHighlightPaint);

            // 4. Оформление папок
            if (n.isFolder) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(12);
                p.setColor(Color.parseColor("#FFCA28")); // Золотой контур папки
                canvas.drawCircle(n.x, n.y, radius + 12, p);
                p.setStyle(Paint.Style.FILL);
            }

            // 5. Рисуем текст
            p.setColor(isColorLight(n.color) ? Color.parseColor("#222222") : Color.WHITE);
            drawSmartText(canvas, n.isFolder ? "📁\n" + n.title : n.title, n.x, n.y, radius);
        }
        canvas.restore();
    }

    private void drawSmartText(Canvas canvas, String text, float cx, float cy, float radius) {
        float maxWidth = radius * 1.6f;
        float fontSize = radius * 0.35f; 
        p.setTextSize(fontSize);

        // Логика отображения иконок папок
        if (text.startsWith("📁\n")) {
            String title = text.substring(3);
            canvas.drawText("📁", cx, cy - (fontSize * 0.1f), p);
            float titleFontSize = radius * 0.25f;
            p.setTextSize(titleFontSize);
            if (p.measureText(title) > maxWidth) title = title.substring(0, Math.max(0, title.length() - 3)) + "..";
            canvas.drawText(title, cx, cy + (fontSize * 0.8f), p);
            return;
        }

        // Авто-перенос длинного текста на две строки
        String[] words = text.split(" ");
        if (words.length > 1 && text.length() > 8) {
            String l1 = words[0], l2 = text.substring(l1.length()).trim();
            while (p.measureText(l1) > maxWidth || p.measureText(l2) > maxWidth) {
                fontSize -= 1; p.setTextSize(fontSize);
                if (fontSize < 16) break;
            }
            canvas.drawText(l1, cx, cy - (fontSize * 0.2f), p);
            canvas.drawText(l2, cx, cy + (fontSize * 0.8f), p);
        } else {
            // Обычный текст в одну строку
            while (p.measureText(text) > maxWidth) {
                fontSize -= 1; p.setTextSize(fontSize);
                if (fontSize < 16) { 
                    text = text.substring(0, Math.max(0, text.length() - 3)) + ".."; 
                    break; 
                }
            }
            canvas.drawText(text, cx, cy + (fontSize / 3f), p);
        }
    }

    private boolean isColorLight(int color) {
        return (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255 > 0.7;
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        gestureDetector.onTouchEvent(event);
        
        float[] pts = mapCoords(event.getX(), event.getY());
        
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                for (NoteItem n : getVisibleNotes()) {
                    if (Math.hypot(pts[0] - n.x, pts[1] - n.y) < getRadius(n)) {
                        dragNote = n; 
                        lastX = pts[0]; 
                        lastY = pts[1]; 
                        break;
                    }
                }
                break;

            case MotionEvent.ACTION_MOVE:
                if (dragNote != null) {
                    dragNote.x += (pts[0] - lastX); 
                    dragNote.y += (pts[1] - lastY);
                    lastX = pts[0]; 
                    lastY = pts[1];
                    
                    // Поиск ближайшего пузырька для слияния
                    highlightNote = null;
                    for (NoteItem n : getVisibleNotes()) {
                        if (n != dragNote && Math.hypot(dragNote.x - n.x, dragNote.y - n.y) < (getRadius(n) * 0.9f)) {
                            highlightNote = n; 
                            break;
                        }
                    }
                    invalidate();
                }
                break;

            case MotionEvent.ACTION_UP:
                if (dragNote != null) {
                    if (highlightNote != null) {
                        // Сообщаем Activity, что нужно объединить два пузырька
                        listener.onMerge(dragNote, highlightNote);
                    } else {
                        // Просто сохраняем новые координаты
                        listener.onDragEnd(dragNote.id, dragNote.x, dragNote.y);
                    }
                }
                dragNote = null; 
                highlightNote = null; 
                invalidate();
                break;
        }
        return true;
    }

    private float[] mapCoords(float x, float y) {
        Matrix inv = new Matrix(); 
        matrix.invert(inv);
        float[] pts = {x, y}; 
        inv.mapPoints(pts);
        return pts;
    }
}