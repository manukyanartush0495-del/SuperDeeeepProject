package com.notes.app;

import android.content.Context;
import android.graphics.*;
import android.view.*;

public class DrawingView extends View {

    public enum Mode { PEN, ERASER, RECT, CIRCLE, ARROW }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.DITHER_FLAG);
    private final Path  path  = new Path();
    private Bitmap bitmap;
    private Canvas bitmapCanvas;
    
    private Mode currentMode = Mode.PEN;
    private float startX, startY, currentX, currentY;
    private int currentColor = Color.BLACK;
    private float currentStrokeWidth = 10f;

    public DrawingView(Context ctx, int w, int h) {
        super(ctx);
        bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        bitmapCanvas = new Canvas(bitmap);
        setupPaint();
    }

    private void setupPaint() {
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(currentStrokeWidth);
        paint.setColor(currentColor);
    }

    public void setMode(Mode mode) { 
        this.currentMode = mode; 
        if (mode == Mode.ERASER) {
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        } else {
            paint.setXfermode(null);
            paint.setColor(currentColor);
        }
    }

    public void setStrokeColor(int color) { 
        this.currentColor = color; 
        if (currentMode != Mode.ERASER) paint.setColor(color); 
    }

    public void setStrokeWidth(float w) { 
        this.currentStrokeWidth = w;
        paint.setStrokeWidth(w); 
    }

    public void clearCanvas() {
        bitmapCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        path.reset(); // Очищаем текущий путь
        startX = startY = currentX = currentY = 0; // Сбрасываем координаты фигур
        invalidate();
    }

    public void loadBitmap(Bitmap src) {
        bitmapCanvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        if (src != null) bitmapCanvas.drawBitmap(src, 0, 0, null);
        invalidate();
    }

    public Bitmap getBitmap() { return bitmap; }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawBitmap(bitmap, 0, 0, null);
        if (currentMode == Mode.PEN || currentMode == Mode.ERASER) {
            canvas.drawPath(path, paint);
        } else {
            // Рисуем превью фигуры только если мы в процессе движения
            if (currentX != 0 || currentY != 0) {
                drawShape(canvas, startX, startY, currentX, currentY, paint, currentMode);
            }
        }
    }

    private void drawShape(Canvas canvas, float x1, float y1, float x2, float y2, Paint p, Mode mode) {
        if (mode == Mode.RECT) {
            canvas.drawRect(Math.min(x1, x2), Math.min(y1, y2), Math.max(x1, x2), Math.max(y1, y2), p);
        } else if (mode == Mode.CIRCLE) {
            float r = (float) Math.hypot(x2 - x1, y2 - y1);
            canvas.drawCircle(x1, y1, r, p);
        } else if (mode == Mode.ARROW) {
            drawArrow(canvas, x1, y1, x2, y2, p);
        }
    }

    private void drawArrow(Canvas canvas, float x1, float y1, float x2, float y2, Paint p) {
        canvas.drawLine(x1, y1, x2, y2, p);
        float angle = (float) Math.atan2(y2 - y1, x2 - x1);
        float radius = p.getStrokeWidth() * 3f + 20f;
        canvas.drawLine(x2, y2, (float)(x2 - radius * Math.cos(angle - Math.PI/6)), (float)(y2 - radius * Math.sin(angle - Math.PI/6)), p);
        canvas.drawLine(x2, y2, (float)(x2 - radius * Math.cos(angle + Math.PI/6)), (float)(y2 - radius * Math.sin(angle + Math.PI/6)), p);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        currentX = event.getX();
        currentY = event.getY();
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                startX = currentX; startY = currentY;
                if (currentMode == Mode.PEN || currentMode == Mode.ERASER) path.moveTo(startX, startY);
                break;
            case MotionEvent.ACTION_MOVE:
                if (currentMode == Mode.PEN || currentMode == Mode.ERASER) {
                    path.lineTo(currentX, currentY);
                    if (currentMode == Mode.ERASER) bitmapCanvas.drawPath(path, paint);
                }
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
                if (currentMode == Mode.PEN || currentMode == Mode.ERASER) {
                    bitmapCanvas.drawPath(path, paint);
                } else {
                    drawShape(bitmapCanvas, startX, startY, currentX, currentY, paint, currentMode);
                }
                path.reset();
                currentX = currentY = 0; // Сброс для очистки превью
                invalidate();
                break;
        }
        return true;
    }
}