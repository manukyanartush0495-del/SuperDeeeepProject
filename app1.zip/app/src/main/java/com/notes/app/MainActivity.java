package com.notes.app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private View mainLayout, topBar, dimOverlay;
    private TextView tvMainTitle;
    private EditText searchInput;
    private FloatingActionButton fabMain, fabNote, fabSnake, fabMusic;

    private boolean isMenuOpen = false;
    private boolean isListView = false;
    private List<NoteItem> notes = new ArrayList<>();
    private List<NoteItem> allNotesFull = new ArrayList<>();
    private NoteAdapter adapter;
    private SharedPreferences prefs;
    private long currentFolderId = -1;

    // Плеер
    private CardView playerCard;
    private TextView tvStation;
    private MediaPlayer mediaPlayer;
    private ImageButton btnPlayPause, btnNext, btnPrev;
    private int currentStationIndex = 0;
    private final String[] stationUrls = {
            "https://stream.laut.fm/lofi",
            "https://stream.zeno.fm/f3wvbbqmdg8uv",
            "https://stream.zeno.fm/0r0xa792kwzuv"
    };
    private final String[] stationNames = {"Lo-Fi Beats ☕", "Chillhop 24/7 🎧", "Lofi Girl 🌙"};

    // Drag & Drop
    private int dragFrom = -1;
    private int dragTo = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        prefs = getSharedPreferences("notes_prefs", MODE_PRIVATE);
        isListView = prefs.getBoolean("isListView", false);

        initViews();
        setupRecyclerView();
        setupListeners();
        initPlayerUI();
        applyTheme();
        loadNotes();
    }

    private void initViews() {
        recyclerView = findViewById(R.id.recyclerView);
        mainLayout   = findViewById(R.id.mainLayout);
        topBar       = findViewById(R.id.topBar);
        tvMainTitle  = findViewById(R.id.tvMainTitle);
        dimOverlay   = findViewById(R.id.dimOverlay);
        searchInput  = findViewById(R.id.searchInput);
        fabMain      = findViewById(R.id.fabMain);
        fabNote      = findViewById(R.id.fabNote);
        fabSnake     = findViewById(R.id.fabSnake);
        fabMusic     = findViewById(R.id.fabMusic);

        searchInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { filterNotes(s.toString()); }
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(android.text.Editable s) {}
        });
    }

    private void setupRecyclerView() {
        adapter = new NoteAdapter(notes, new NoteAdapter.OnNoteClickListener() {
            @Override public void onNoteClick(long id) {
                if (prefs.getBoolean("isFolder_" + id, false)) {
                    currentFolderId = id;
                    loadNotes();
                } else {
                    startActivity(new Intent(MainActivity.this, NoteEditorActivity.class)
                        .putExtra("note_id", id));
                }
            }
            @Override public void onOptionsClick(long id) { showContextMenu(id); }
        });

        updateLayoutManager();
        recyclerView.setAdapter(adapter);

        ItemTouchHelper touchHelper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(
                ItemTouchHelper.UP | ItemTouchHelper.DOWN |
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT, 0) {

            @Override
            public boolean onMove(@NonNull RecyclerView rv,
                                  @NonNull RecyclerView.ViewHolder vh,
                                  @NonNull RecyclerView.ViewHolder target) {
                int from = vh.getAdapterPosition();
                int to   = target.getAdapterPosition();
                if (dragFrom == -1) dragFrom = from;
                dragTo = to;
                if (from != to) {
                    Collections.swap(notes, from, to);
                    adapter.notifyItemMoved(from, to);
                }
                return true;
            }

            @Override
            public void clearView(@NonNull RecyclerView rv, @NonNull RecyclerView.ViewHolder vh) {
                super.clearView(rv, vh);
                if (dragFrom != -1 && dragTo != -1 && dragFrom != dragTo) {
                    checkMerge(dragFrom, dragTo);
                }
                // ✅ FIX: saveOrder не перезаписывает all_ids полностью,
                //         а только обновляет порядок видимых заметок
                saveOrderSafe();
                dragFrom = dragTo = -1;
            }

            @Override public void onSwiped(@NonNull RecyclerView.ViewHolder vh, int dir) {}
        });
        touchHelper.attachToRecyclerView(recyclerView);
    }

    private void checkMerge(int from, int to) {
        if (from < 0 || to < 0 || from >= notes.size() || to >= notes.size()) return;
        NoteItem dragged = notes.get(from);
        NoteItem target  = notes.get(to);

        new AlertDialog.Builder(this)
            .setTitle("Создать группу?")
            .setMessage("Объединить эти заметки в папку?")
            .setPositiveButton("Да", (d, w) -> {
                EditText input = new EditText(this);
                input.setHint("Название группы");
                new AlertDialog.Builder(this)
                    .setTitle("Имя группы")
                    .setView(input)
                    .setPositiveButton("Создать", (d2, w2) -> {
                        long folderId = System.currentTimeMillis();
                        String name = input.getText().toString().trim();
                        if (name.isEmpty()) name = "Группа";

                        String allIds = prefs.getString("all_ids", "");
                        if (!allIds.isEmpty()) allIds += ",";
                        allIds += folderId;

                        prefs.edit()
                            .putString("all_ids", allIds)
                            .putBoolean("isFolder_" + folderId, true)
                            .putString("title_" + folderId, name)
                            .putInt("color_" + folderId, Color.parseColor("#FFCA28"))
                            .putLong("parentId_" + folderId, currentFolderId)
                            .putLong("parentId_" + dragged.id, folderId)
                            .putLong("parentId_" + target.id, folderId)
                            .apply();
                        loadNotes();
                    })
                    .setNegativeButton("Отмена", null)
                    .show();
            })
            .setNegativeButton("Нет", null)
            .show();
    }

    private void updateLayoutManager() {
        if (isListView)
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
        else
            recyclerView.setLayoutManager(
                new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));
    }

    private void setupListeners() {
        fabMain.setOnClickListener(v -> toggleMenu());
        dimOverlay.setOnClickListener(v -> { if (isMenuOpen) toggleMenu(); });

        fabNote.setOnClickListener(v -> { toggleMenu(); showCreateDialog(); });
        fabSnake.setOnClickListener(v -> { toggleMenu(); startActivity(new Intent(this, SnakeActivity.class)); });
        fabMusic.setOnClickListener(v -> { toggleMenu(); showPlayerCard(); });

        findViewById(R.id.btnTheme).setOnClickListener(v -> {
            int t = (prefs.getInt("themeIndex", 0) + 1) % 6;
            prefs.edit().putInt("themeIndex", t).apply();
            applyTheme();
        });

        findViewById(R.id.btnViewToggle).setOnClickListener(v -> {
            isListView = !isListView;
            prefs.edit().putBoolean("isListView", isListView).apply();
            updateLayoutManager();
        });

        // Кнопка "Назад" из папки — долгое нажатие на заголовок
        tvMainTitle.setOnClickListener(v -> {
            if (currentFolderId != -1) {
                currentFolderId = -1;
                loadNotes();
            }
        });

        findViewById(R.id.btnBubbleMode).setOnClickListener(v ->
            startActivity(new Intent(this, BubbleActivity.class)
                .putExtra("open_folder_id", currentFolderId))
        );
    }

    // ══════════════════════════════════════════════════════════
    //  FAB-меню — ✅ FIX: убраны translationY из XML,
    //  анимация считается от одной точки вниз
    // ══════════════════════════════════════════════════════════
    private void toggleMenu() {
        // Шаг между кнопками в пикселях (56dp mini-FAB + 12dp отступ)
        float step = 68 * getResources().getDisplayMetrics().density;

        if (!isMenuOpen) {
            dimOverlay.setVisibility(View.VISIBLE);
            dimOverlay.setAlpha(0f);
            dimOverlay.animate().alpha(1f).setDuration(200).start();

            // Сначала ставим кнопки в стартовую позицию (под fabMain) и делаем видимыми
            fabNote.setTranslationY(0f);  fabNote.setAlpha(0f);  fabNote.setVisibility(View.VISIBLE);
            fabSnake.setTranslationY(0f); fabSnake.setAlpha(0f); fabSnake.setVisibility(View.VISIBLE);
            fabMusic.setTranslationY(0f); fabMusic.setAlpha(0f); fabMusic.setVisibility(View.VISIBLE);

            // Анимируем вверх — отрицательные translationY = выше на экране
            fabNote.animate().translationY(-step * 1).alpha(1f).setDuration(250).start();
            fabSnake.animate().translationY(-step * 2).alpha(1f).setDuration(250).start();
            fabMusic.animate().translationY(-step * 3).alpha(1f).setDuration(250).start();

            fabMain.animate().rotation(45f).setDuration(250).start();
            isMenuOpen = true;
        } else {
            dimOverlay.animate().alpha(0f)
                .withEndAction(() -> dimOverlay.setVisibility(View.GONE))
                .setDuration(200).start();

            fabNote.animate().translationY(0f).alpha(0f).setDuration(200).start();
            fabSnake.animate().translationY(0f).alpha(0f).setDuration(200).start();
            fabMusic.animate().translationY(0f).alpha(0f).setDuration(200)
                .withEndAction(() -> {
                    fabNote.setVisibility(View.INVISIBLE);
                    fabSnake.setVisibility(View.INVISIBLE);
                    fabMusic.setVisibility(View.INVISIBLE);
                }).start();

            fabMain.animate().rotation(0f).setDuration(200).start();
            isMenuOpen = false;
        }
    }

    // ══════════════════════════════════════════════════════════
    //  СОЗДАНИЕ — ✅ FIX: добавлена кнопка "Папка"
    // ══════════════════════════════════════════════════════════
    private void showCreateDialog() {
        String[] types = {"📝 Заметка", "📁 Папка"};
        new AlertDialog.Builder(this)
            .setTitle("Создать")
            .setItems(types, (d, which) -> {
                if (which == 0) showCreateNoteDialog();
                else showCreateFolderDialog();
            }).show();
    }

    private void showCreateNoteDialog() {
        long id = System.currentTimeMillis();
        String allIds = prefs.getString("all_ids", "");
        prefs.edit()
            .putString("all_ids", allIds.isEmpty() ? String.valueOf(id) : allIds + "," + id)
            .putString("title_" + id, "")
            .putLong("parentId_" + id, currentFolderId)
            .putInt("color_" + id, Color.WHITE)
            .apply();
        startActivity(new Intent(this, NoteEditorActivity.class)
            .putExtra("note_id", id));
    }

    private void showCreateFolderDialog() {
        EditText input = new EditText(this);
        input.setHint("Название папки");
        new AlertDialog.Builder(this)
            .setTitle("Новая папка")
            .setView(input)
            .setPositiveButton("Создать", (d, w) -> {
                String name = input.getText().toString().trim();
                if (name.isEmpty()) name = "Папка";
                long id = System.currentTimeMillis();
                String allIds = prefs.getString("all_ids", "");
                prefs.edit()
                    .putString("all_ids", allIds.isEmpty() ? String.valueOf(id) : allIds + "," + id)
                    .putBoolean("isFolder_" + id, true)
                    .putString("title_" + id, name)
                    .putInt("color_" + id, Color.parseColor("#FFCA28"))
                    .putLong("parentId_" + id, currentFolderId)
                    .apply();
                loadNotes();
            })
            .setNegativeButton("Отмена", null)
            .show();
    }

    // ══════════════════════════════════════════════════════════
    //  ЗАГРУЗКА ЗАМЕТОК — ✅ FIX: папка не исчезает,
    //  title обновляется при входе в папку
    // ══════════════════════════════════════════════════════════
    void loadNotes() {
        notes.clear();
        allNotesFull.clear();

        // Обновляем заголовок экрана
        if (currentFolderId == -1) {
            tvMainTitle.setText("Заметки");
        } else {
            tvMainTitle.setText("← " + prefs.getString("title_" + currentFolderId, "Папка"));
        }

        String idString = prefs.getString("all_ids", "");
        List<NoteItem> pinned  = new ArrayList<>();
        List<NoteItem> regular = new ArrayList<>();

        if (!idString.isEmpty()) {
            for (String sId : idString.split(",")) {
                if (sId.trim().isEmpty()) continue;
                try {
                    long id = Long.parseLong(sId.trim());
                    long parentId = prefs.getLong("parentId_" + id, -1);

                    if (parentId == currentFolderId) {
                        NoteItem item = new NoteItem(
                            id,
                            prefs.getString("title_" + id, ""),
                            prefs.getString("note_"  + id, ""),
                            prefs.getString("date_"  + id, ""),
                            prefs.getInt("color_"    + id, Color.WHITE)
                        );
                        item.isFolder = prefs.getBoolean("isFolder_" + id, false);
                        item.isPinned = prefs.getBoolean("pinned_"   + id, false);
                        allNotesFull.add(item);
                        if (item.isPinned) pinned.add(item);
                        else regular.add(item);
                    }
                } catch (NumberFormatException ignored) {}
            }
        }

        notes.addAll(pinned);
        notes.addAll(regular);
        adapter.notifyDataSetChanged();
    }

    // ══════════════════════════════════════════════════════════
    //  ТЕМА — ✅ FIX: сохраняем цвет фона в prefs,
    //  BubbleActivity сможет его прочитать
    // ══════════════════════════════════════════════════════════
    void applyTheme() {
        int themeIndex = prefs.getInt("themeIndex", 0);
        int[] bgColors = {0xFFF2F3F7, 0xFFFFF0F5, 0xFFF4FAF6, 0xFFF8F4FF, 0xFFFFF5E6, 0xFFF0F8FF};
        int[] accents  = {0xFF1A1A2E,  0xFFD81B60,  0xFF2E7D32,  0xFF512DA8,  0xFFE65100,  0xFF0277BD};
        int bg  = bgColors[themeIndex];
        int acc = accents[themeIndex];

        mainLayout.setBackgroundColor(bg);
        tvMainTitle.setTextColor(acc);
        fabMain.setBackgroundTintList(android.content.res.ColorStateList.valueOf(acc));

        // ✅ Сохраняем цвет фона чтобы BubbleActivity мог его применить
        prefs.edit()
            .putInt("theme_bg_color", bg)
            .putInt("theme_accent_color", acc)
            .apply();

        if (android.os.Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(bg);
        }
    }

    // ══════════════════════════════════════════════════════════
    //  СОХРАНЕНИЕ ПОРЯДКА — ✅ FIX: не стирает скрытые заметки
    // ══════════════════════════════════════════════════════════
    private void saveOrderSafe() {
        String allIds = prefs.getString("all_ids", "");
        if (allIds.isEmpty()) return;

        // Собираем все ID которые сейчас видны (в текущей папке)
        Set<Long> visibleIds = new HashSet<>();
        for (NoteItem n : notes) visibleIds.add(n.id);

        // Строим новый порядок: сначала видимые (в новом порядке после drag),
        // потом все невидимые (в других папках) — они не трогаются
        List<String> newOrder = new ArrayList<>();
        // Добавляем видимые в порядке после drag
        for (NoteItem n : notes) newOrder.add(String.valueOf(n.id));
        // Добавляем все остальные (не в текущей папке)
        for (String sId : allIds.split(",")) {
            if (sId.trim().isEmpty()) continue;
            try {
                long id = Long.parseLong(sId.trim());
                if (!visibleIds.contains(id)) newOrder.add(String.valueOf(id));
            } catch (NumberFormatException ignored) {}
        }

        StringBuilder sb = new StringBuilder();
        for (String s : newOrder) {
            if (sb.length() > 0) sb.append(",");
            sb.append(s);
        }
        prefs.edit().putString("all_ids", sb.toString()).apply();
    }

    // ══════════════════════════════════════════════════════════
    //  КОНТЕКСТНОЕ МЕНЮ
    // ══════════════════════════════════════════════════════════
    private void showContextMenu(long id) {
        boolean isPinned = prefs.getBoolean("pinned_" + id, false);
        boolean isFolder = prefs.getBoolean("isFolder_" + id, false);
        String[] options = {
            isPinned ? "📌 Открепить" : "📌 Закрепить",
            "✏ Переименовать",
            isFolder ? null : "⭐ Приоритет",
            "🗑 Удалить"
        };

        // Фильтруем null
        List<String> filtered = new ArrayList<>();
        for (String o : options) if (o != null) filtered.add(o);
        String[] items = filtered.toArray(new String[0]);

        new AlertDialog.Builder(this)
            .setTitle("Действие")
            .setItems(items, (dialog, which) -> {
                String chosen = items[which];
                if (chosen.contains("Закрепить") || chosen.contains("Открепить")) {
                    prefs.edit().putBoolean("pinned_" + id, !isPinned).apply();
                    loadNotes();
                } else if (chosen.contains("Переименовать")) {
                    renameFolder(id);
                } else if (chosen.contains("Приоритет")) {
                    showPriorityDialog(id);
                } else if (chosen.contains("Удалить")) {
                    handleDelete(id);
                }
            }).show();
    }

    private void showPriorityDialog(long id) {
        String[] options = {"🔴 Высокий", "🟡 Средний", "🟢 Низкий"};
        new AlertDialog.Builder(this)
            .setTitle("Приоритет")
            .setItems(options, (d, w) -> {
                prefs.edit().putInt("priority_" + id, w).apply();
                loadNotes();
            }).show();
    }

    private void handleDelete(long id) {
        new AlertDialog.Builder(this)
            .setTitle("Удалить?")
            .setMessage("\"" + prefs.getString("title_" + id, "") + "\"")
            .setPositiveButton("Удалить", (d, w) -> {
                String ids = prefs.getString("all_ids", "");
                // Аккуратно удаляем конкретный id не задев похожие числа
                String[] parts = ids.split(",");
                StringBuilder sb = new StringBuilder();
                for (String p : parts) {
                    if (!p.trim().equals(String.valueOf(id))) {
                        if (sb.length() > 0) sb.append(",");
                        sb.append(p.trim());
                    }
                }
                prefs.edit()
                    .putString("all_ids", sb.toString())
                    .remove("title_"   + id)
                    .remove("note_"    + id)
                    .remove("color_"   + id)
                    .remove("date_"    + id)
                    .remove("pinned_"  + id)
                    .remove("isFolder_"+ id)
                    .remove("parentId_"+ id)
                    .apply();
                loadNotes();
            })
            .setNegativeButton("Отмена", null)
            .show();
    }

    private void renameFolder(long id) {
        EditText input = new EditText(this);
        input.setText(prefs.getString("title_" + id, ""));
        new AlertDialog.Builder(this)
            .setTitle("Новое имя")
            .setView(input)
            .setPositiveButton("OK", (d, w) -> {
                prefs.edit().putString("title_" + id, input.getText().toString().trim()).apply();
                loadNotes();
            }).show();
    }

    private void filterNotes(String query) {
        List<NoteItem> filtered = new ArrayList<>();
        for (NoteItem n : allNotesFull) {
            if (n.title.toLowerCase().contains(query.toLowerCase())
             || n.content.toLowerCase().contains(query.toLowerCase())) {
                filtered.add(n);
            }
        }
        notes.clear();
        notes.addAll(filtered);
        adapter.notifyDataSetChanged();
    }

    // ══════════════════════════════════════════════════════════
    //  ПЛЕЕР
    // ══════════════════════════════════════════════════════════
    private void initPlayerUI() {
        ViewGroup root = findViewById(android.R.id.content);
        if (root.findViewWithTag("playerCard") != null) {
            playerCard = (CardView) root.findViewWithTag("playerCard");
            return;
        }

        playerCard = new CardView(this);
        playerCard.setTag("playerCard");

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM);
        params.setMargins(36, 0, 36, 120);
        playerCard.setLayoutParams(params);
        playerCard.setRadius(28f);
        playerCard.setCardElevation(24f);
        playerCard.setCardBackgroundColor(Color.parseColor("#1E1E1E"));
        playerCard.setVisibility(View.GONE);

        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.setPadding(24, 20, 24, 20);

        tvStation = new TextView(this);
        tvStation.setTextColor(Color.WHITE);
        tvStation.setTextSize(17);
        tvStation.setGravity(Gravity.CENTER);
        ll.addView(tvStation);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(0, 16, 0, 0);

        btnPrev      = createControlButton(android.R.drawable.ic_media_previous);
        btnPlayPause = createControlButton(android.R.drawable.ic_media_play);
        btnNext      = createControlButton(android.R.drawable.ic_media_next);

        btnPrev.setOnClickListener(v -> playStation((currentStationIndex - 1 + stationUrls.length) % stationUrls.length));
        btnPlayPause.setOnClickListener(v -> togglePlayPause());
        btnNext.setOnClickListener(v -> playStation((currentStationIndex + 1) % stationUrls.length));

        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(64, 64);
        btnLp.setMargins(24, 0, 24, 0);
        controls.addView(btnPrev,      btnLp);
        controls.addView(btnPlayPause, btnLp);
        controls.addView(btnNext,      btnLp);
        ll.addView(controls);

        ImageButton btnClose = new ImageButton(this);
        btnClose.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
        btnClose.setBackgroundColor(0);
        btnClose.setColorFilter(Color.GRAY);
        btnClose.setOnClickListener(v -> hidePlayerCard());
        ll.addView(btnClose);

        playerCard.addView(ll);
        root.addView(playerCard);
    }

    private ImageButton createControlButton(int resId) {
        ImageButton btn = new ImageButton(this);
        btn.setImageResource(resId);
        btn.setBackgroundColor(0);
        btn.setColorFilter(Color.WHITE);
        return btn;
    }

    private void togglePlayPause() {
        if (mediaPlayer == null) return;
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            btnPlayPause.setImageResource(android.R.drawable.ic_media_play);
        } else {
            mediaPlayer.start();
            btnPlayPause.setImageResource(android.R.drawable.ic_media_pause);
        }
    }

    private void playStation(int index) {
        currentStationIndex = index;
        if (mediaPlayer == null) mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.reset();
            mediaPlayer.setDataSource(stationUrls[index]);
            mediaPlayer.setOnPreparedListener(mp -> {
                tvStation.setText(stationNames[index]);
                mp.start();
                btnPlayPause.setImageResource(android.R.drawable.ic_media_pause);
            });
            mediaPlayer.setOnErrorListener((mp, what, extra) -> {
                tvStation.setText("Ошибка соединения");
                return true;
            });
            mediaPlayer.prepareAsync();
            tvStation.setText("Загрузка...");
        } catch (Exception e) {
            Log.e("MusicPlayer", "Exception", e);
        }
    }

    private void showPlayerCard() {
        if (playerCard.getVisibility() == View.VISIBLE) { hidePlayerCard(); return; }
        playerCard.setVisibility(View.VISIBLE);
        playerCard.setAlpha(0f);
        playerCard.setTranslationY(100f);
        playerCard.animate().alpha(1f).translationY(0f).setDuration(300).start();
        if (mediaPlayer == null || !mediaPlayer.isPlaying()) playStation(0);
    }

    private void hidePlayerCard() {
        playerCard.animate().alpha(0f).translationY(100f).setDuration(300)
            .withEndAction(() -> playerCard.setVisibility(View.GONE)).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadNotes();
        applyTheme();
    }

    @Override
    protected void onDestroy() {
        if (mediaPlayer != null) { mediaPlayer.release(); mediaPlayer = null; }
        super.onDestroy();
    }
}