package com.notes.app;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> {

    public interface OnNoteClickListener {
        void onNoteClick(long id);
        void onOptionsClick(long id);
    }

    private List<NoteItem> notes;
    private final OnNoteClickListener listener;

    public NoteAdapter(List<NoteItem> notes, OnNoteClickListener listener) {
        this.notes = notes;
        this.listener = listener;
    }

    public void updateList(List<NoteItem> newList) {
        notes = newList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_note, parent, false);
        return new NoteViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {
        NoteItem note = notes.get(position);

        // ── Текст ─────────────────────────────────────────────
        holder.tvTitle.setText(note.title);
        holder.tvContent.setText(note.content);
        holder.tvDate.setText(note.date);

        if (note.isFolder) {
            holder.tvTitle.setText("📁 " + note.title);
            holder.tvContent.setVisibility(View.GONE);
        } else {
            holder.tvContent.setVisibility(View.VISIBLE);
        }

        if (note.isPinned) {
            holder.tvTitle.setText("📌 " + holder.tvTitle.getText());
        }

        // ── Цвет карточки ─────────────────────────────────────
        // Фон карточки — всегда белый/светлый, цвет виден в полоске
        holder.cardView.setCardBackgroundColor(Color.WHITE);

        // Цветная полоска слева
        if (holder.colorStripe != null) {
            int stripeColor = note.color;
            // Если цвет почти белый — полоску делаем светло-серой
            if (isAlmostWhite(stripeColor)) {
                stripeColor = Color.parseColor("#E0E0E0");
            }
            holder.colorStripe.setBackgroundColor(stripeColor);
        }

        // ── Цвет текста — всегда тёмный (фон карточки белый) ──
        holder.tvTitle.setTextColor(Color.parseColor("#111111"));
        holder.tvContent.setTextColor(Color.parseColor("#555555"));
        holder.tvDate.setTextColor(Color.parseColor("#AAAAAA"));
        holder.tvDate.setAlpha(1f);
        holder.btnOptions.clearColorFilter();
        holder.btnOptions.setAlpha(0.35f);

        // ── Клики ─────────────────────────────────────────────
        holder.itemView.setOnClickListener(v -> listener.onNoteClick(note.id));
        holder.btnOptions.setOnClickListener(v -> listener.onOptionsClick(note.id));

        // ── Анимация появления ─────────────────────────────────
        holder.itemView.setAlpha(0f);
        holder.itemView.animate()
            .alpha(1f)
            .setDuration(180)
            .setStartDelay(position * 30L)
            .start();
    }

    /** Проверяем, что цвет почти белый (яркость > 95%) */
    private boolean isAlmostWhite(int color) {
        double brightness = (0.299 * Color.red(color)
                           + 0.587 * Color.green(color)
                           + 0.114 * Color.blue(color)) / 255.0;
        return brightness > 0.95;
    }

    private boolean isDarkColor(int color) {
        return (1 - (0.299 * Color.red(color)
                   + 0.587 * Color.green(color)
                   + 0.114 * Color.blue(color)) / 255) > 0.5;
    }

    @Override
    public int getItemCount() { return notes.size(); }

    static class NoteViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvContent, tvDate;
        ImageButton btnOptions;
        CardView cardView;
        View colorStripe; // ← полоска цвета слева

        public NoteViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle     = itemView.findViewById(R.id.tvTitle);
            tvContent   = itemView.findViewById(R.id.tvContent);
            tvDate      = itemView.findViewById(R.id.tvDate);
            btnOptions  = itemView.findViewById(R.id.btnOptions);
            cardView    = itemView.findViewById(R.id.cardView);
            colorStripe = itemView.findViewById(R.id.colorStripe);
        }
    }
}