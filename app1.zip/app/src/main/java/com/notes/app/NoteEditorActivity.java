package com.notes.app;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.util.Log;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class NoteEditorActivity extends AppCompatActivity {

    private static final String TAG = "NoteEditor";
    private static final int REQUEST_PICK_IMAGE = 1001;

    private EditText editTitle, editContent;
    private FrameLayout floatingLayer;
    private DrawingView drawingView;
    private ImageView drawingSnapshot;
    private long noteId = -1;
    private int selectedColor = Color.WHITE;
    private SharedPreferences prefs;

    // ── ЧЕК-ЛИСТ ──────────────────────────────────────────────
    private LinearLayout checklistContainer;
    private boolean isChecklistMode = false;
    private List<ChecklistItem> checklistItems = new ArrayList<>();

    // ── ЦВЕТА ДЛЯ ПАЛИТРЫ ──────────────────────────────────────
    private static final int[] NOTE_COLORS = {
        0xFFFFFFFF, // белый
        0xFFFFF9C4, // жёлтый
        0xFFFFCDD2, // розовый
        0xFFE8F5E9, // зелёный
        0xFFE3F2FD, // голубой
        0xFFEDE7F6, // фиолетовый
        0xFFFFE0B2, // оранжевый
        0xFFCFD8DC, // серый
        0xFF80CBC4, // бирюзовый насыщ.
        0xFFF48FB1, // розовый насыщ.
        0xFF90CAF9, // голубой насыщ.
        0xFFA5D6A7, // зелёный насыщ.
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_editor);

        if (getSupportActionBar() != null) getSupportActionBar().hide();
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            getWindow().setStatusBarColor(Color.TRANSPARENT);
        }

        prefs  = getSharedPreferences("notes_prefs", MODE_PRIVATE);
        noteId = getIntent().getLongExtra("note_id", -1);

        editTitle   = findViewById(R.id.editTitle);
        editContent = findViewById(R.id.editContent);
        floatingLayer = findViewById(R.id.floatingLayer);

        initDrawingLayer();
        initChecklistUI();

        if (noteId != -1) {
            loadNoteData();
            restoreMediaAndDrawing();
        } else {
            findViewById(R.id.editorLayout).setBackgroundColor(Color.WHITE);
        }

        setupListeners();
    }

    // ══════════════════════════════════════════════════════════
    //  ЧЕК-ЛИСТ — кнопка теперь в тулбаре XML (btnChecklist)
    //  Если в твоём XML пока нет btnChecklist — добавь его
    //  рядом с другими ImageButton в editorToolbar:
    //
    //  <ImageButton android:id="@+id/btnChecklist"
    //      android:layout_width="40dp" android:layout_height="40dp"
    //      android:src="@android:drawable/btn_star"
    //      android:background="?android:attr/selectableItemBackgroundBorderless"
    //      android:layout_marginEnd="8dp"/>
    // ══════════════════════════════════════════════════════════
    private void initChecklistUI() {
        checklistContainer = new LinearLayout(this);
        checklistContainer.setOrientation(LinearLayout.VERTICAL);
        checklistContainer.setVisibility(View.GONE);

        // Добавляем контейнер сразу под editContent (в тот же LinearLayout)
        ViewGroup parent = (ViewGroup) editContent.getParent();
        parent.addView(checklistContainer);
    }

    private void toggleChecklistMode() {
        isChecklistMode = !isChecklistMode;

        // Обновляем иконку кнопки если она есть в XML
        ImageButton btn = findViewById(R.id.btnChecklist);
        if (btn != null) {
            btn.setAlpha(isChecklistMode ? 1.0f : 0.5f);
        }

        if (isChecklistMode) {
            editContent.setVisibility(View.GONE);
            checklistContainer.setVisibility(View.VISIBLE);
            loadChecklist();
        } else {
            editContent.setVisibility(View.VISIBLE);
            checklistContainer.setVisibility(View.GONE);
            saveChecklistToText();
        }
    }

    private void loadChecklist() {
        checklistItems.clear();
        String saved = prefs.getString("checklist_" + noteId, "");
        if (!saved.isEmpty()) {
            for (String item : saved.split(";")) {
                if (item.isEmpty()) continue;
                String[] parts = item.split("\\|");
                boolean checked = parts.length > 1 && parts[1].equals("1");
                checklistItems.add(new ChecklistItem(parts[0], checked));
            }
        } else {
            // Если чек-лист пустой — конвертируем текст из обычного поля
            for (String line : editContent.getText().toString().split("\n")) {
                if (!line.trim().isEmpty())
                    checklistItems.add(new ChecklistItem(line.trim(), false));
            }
        }
        rebuildChecklistUI();
    }

    private void rebuildChecklistUI() {
        checklistContainer.removeAllViews();
        int dp = (int) getResources().getDisplayMetrics().density;

        for (int i = 0; i < checklistItems.size(); i++) {
            final int idx = i;
            ChecklistItem item = checklistItems.get(i);

            // Строка чеклиста
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, 6 * dp, 0, 6 * dp);

            // Чекбокс с кастомным стилем
            CheckBox cb = new CheckBox(this);
            cb.setChecked(item.checked);
            cb.setOnCheckedChangeListener((buttonView, isChecked) -> {
                checklistItems.get(idx).checked = isChecked;
                // Зачёркиваем текст при отметке
                EditText et = (EditText) row.getChildAt(1);
                if (et != null) {
                    et.setPaintFlags(isChecked
                        ? et.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG
                        : et.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
                    et.setAlpha(isChecked ? 0.45f : 1f);
                }
            });

            // Поле текста
            EditText et = new EditText(this);
            LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            et.setLayoutParams(etLp);
            et.setText(item.text);
            et.setSingleLine(false);
            et.setBackground(null);
            et.setTextSize(16f);
            et.setTextColor(Color.parseColor("#222222"));
            if (item.checked) {
                et.setPaintFlags(et.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                et.setAlpha(0.45f);
            }
            et.addTextChangedListener(new android.text.TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
                @Override public void onTextChanged(CharSequence s, int st, int b, int c) {
                    checklistItems.get(idx).text = s.toString();
                }
                @Override public void afterTextChanged(android.text.Editable s) {}
            });

            // Кнопка удаления строки
            ImageButton del = new ImageButton(this);
            del.setImageResource(android.R.drawable.ic_delete);
            del.setBackground(null);
            del.setAlpha(0.35f);
            del.setPadding(8 * dp, 8 * dp, 8 * dp, 8 * dp);
            del.setOnClickListener(v -> {
                checklistItems.remove(idx);
                rebuildChecklistUI();
            });

            row.addView(cb);
            row.addView(et);
            row.addView(del);

            // Разделитель
            View divider = new View(this);
            divider.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1));
            divider.setBackgroundColor(Color.parseColor("#15000000"));

            checklistContainer.addView(row);
            checklistContainer.addView(divider);
        }

        // Кнопка «+ Добавить пункт»
        TextView addBtn = new TextView(this);
        addBtn.setText("＋  Добавить пункт");
        addBtn.setTextColor(Color.parseColor("#5C6BC0"));
        addBtn.setTextSize(15f);
        addBtn.setTypeface(addBtn.getTypeface(), Typeface.BOLD);
        addBtn.setPadding(8 * dp, 14 * dp, 8 * dp, 14 * dp);
        addBtn.setBackground(null);
        addBtn.setOnClickListener(v -> {
            checklistItems.add(new ChecklistItem("", false));
            rebuildChecklistUI();
            // Фокус на последнее поле
            int lastRow = checklistContainer.getChildCount() - 3; // перед divider и addBtn
            if (lastRow >= 0) {
                View rowView = checklistContainer.getChildAt(lastRow);
                if (rowView instanceof LinearLayout) {
                    View etView = ((LinearLayout) rowView).getChildAt(1);
                    if (etView instanceof EditText) etView.requestFocus();
                }
            }
        });
        checklistContainer.addView(addBtn);
    }

    private void saveChecklist() {
        if (!isChecklistMode) return;
        StringBuilder sb = new StringBuilder();
        for (ChecklistItem item : checklistItems) {
            if (sb.length() > 0) sb.append(";");
            sb.append(item.text).append("|").append(item.checked ? "1" : "0");
        }
        prefs.edit().putString("checklist_" + noteId, sb.toString()).apply();
    }

    private void saveChecklistToText() {
        StringBuilder sb = new StringBuilder();
        for (ChecklistItem item : checklistItems) {
            if (sb.length() > 0) sb.append("\n");
            sb.append(item.checked ? "☑ " : "☐ ").append(item.text);
        }
        editContent.setText(sb.toString());
    }

    // ══════════════════════════════════════════════════════════
    //  LISTENERS
    // ══════════════════════════════════════════════════════════
    private void setupListeners() {
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnPalette).setOnClickListener(v -> showColorDialog());
        findViewById(R.id.btnMedia).setOnClickListener(v -> showMediaDialog());
        findViewById(R.id.btnDraw).setOnClickListener(v -> {
            if (drawingView.getVisibility() == View.GONE) enterDrawMode();
            else showBrushDialog();
        });

        // ✅ Будильник — вызов системного приложения
        findViewById(R.id.btnSetReminder).setOnClickListener(v -> openSystemAlarm());

        // Кнопка чек-листа (если добавил в XML)
        View btnChecklist = findViewById(R.id.btnChecklist);
        if (btnChecklist != null) {
            btnChecklist.setOnClickListener(v -> toggleChecklistMode());
        }
    }

    // ══════════════════════════════════════════════════════════
    //  БУДИЛЬНИК — открывает системное приложение Часы
    // ══════════════════════════════════════════════════════════
    private void openSystemAlarm() {
        saveNote();

        String label = editTitle.getText().toString().trim();
        if (label.isEmpty()) label = "Напоминание из заметок";

        // AlarmClock.ACTION_SET_ALARM — правильный способ открыть будильник
        try {
            Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM);
            alarmIntent.putExtra(AlarmClock.EXTRA_MESSAGE, label);
            alarmIntent.putExtra(AlarmClock.EXTRA_SKIP_UI, false);
            startActivity(alarmIntent);
        } catch (ActivityNotFoundException e) {
            // Фолбэк 1: пробуем открыть com.android.deskclock напрямую
            try {
                Intent clock = new Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setPackage("com.android.deskclock");
                startActivity(clock);
            } catch (Exception ex) {
                // Фолбэк 2: сообщаем пользователю
                Toast.makeText(this,
                    "Приложение Часы не найдено", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // ══════════════════════════════════════════════════════════
    //  ПАЛИТРА — красивая сетка вместо списка текстом
    // ══════════════════════════════════════════════════════════
    private void showColorDialog() {
        int dp = (int) getResources().getDisplayMetrics().density;

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setPadding(20 * dp, 16 * dp, 20 * dp, 8 * dp);

        AlertDialog[] dialogRef = new AlertDialog[1];

        for (int color : NOTE_COLORS) {
            GradientDrawable gd = new GradientDrawable();
            gd.setColor(color);
            gd.setCornerRadius(16 * dp);
            gd.setStroke(2 * dp, Color.parseColor("#22000000"));

            View swatch = new View(this);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width  = 58 * dp;
            lp.height = 58 * dp;
            lp.setMargins(8 * dp, 8 * dp, 8 * dp, 8 * dp);
            swatch.setLayoutParams(lp);
            swatch.setBackground(gd);

            final int chosenColor = color;
            swatch.setOnClickListener(v -> {
                selectedColor = chosenColor;
                applyNoteColor(chosenColor);
                if (dialogRef[0] != null) dialogRef[0].dismiss();
            });
            grid.addView(swatch);
        }

        dialogRef[0] = new AlertDialog.Builder(this)
            .setTitle("Цвет заметки")
            .setView(grid)
            .setNegativeButton("Отмена", null)
            .create();
        dialogRef[0].show();
    }

    private void applyNoteColor(int color) {
        View root = findViewById(R.id.editorLayout);
        if (root != null) root.setBackgroundColor(color);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(color);
            // Подбираем цвет иконок статус-бара
            boolean isLight = isColorLight(color);
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            if (isLight) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }

    private boolean isColorLight(int color) {
        return (0.299 * Color.red(color)
              + 0.587 * Color.green(color)
              + 0.114 * Color.blue(color)) / 255 > 0.65;
    }

    // ══════════════════════════════════════════════════════════
    //  РИСОВАНИЕ
    // ══════════════════════════════════════════════════════════
    private void initDrawingLayer() {
        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels - 300;

        drawingSnapshot = new ImageView(this);
        drawingSnapshot.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        drawingSnapshot.setScaleType(ImageView.ScaleType.FIT_XY);
        floatingLayer.addView(drawingSnapshot, 0);

        drawingView = new DrawingView(this, w, h);
        drawingView.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        drawingView.setVisibility(View.GONE);
        floatingLayer.addView(drawingView);
    }

    private void enterDrawMode() {
        if (drawingSnapshot.getDrawable() != null) {
            Bitmap current = ((BitmapDrawable) drawingSnapshot.getDrawable()).getBitmap();
            drawingView.loadBitmap(current.copy(Bitmap.Config.ARGB_8888, true));
        }
        drawingSnapshot.setVisibility(View.GONE);
        drawingView.setVisibility(View.VISIBLE);
        findViewById(R.id.btnDraw)
            .animate().scaleX(1.2f).scaleY(1.2f).setDuration(200).start();
        showBrushDialog();
    }

    private void exitDrawMode() {
        Bitmap newDrawing = drawingView.getBitmap();
        drawingSnapshot.setImageBitmap(newDrawing.copy(Bitmap.Config.ARGB_8888, true));
        drawingSnapshot.setVisibility(View.VISIBLE);
        drawingView.setVisibility(View.GONE);
        findViewById(R.id.btnDraw)
            .animate().scaleX(1.0f).scaleY(1.0f).setDuration(200).start();
        saveDrawingNow();
    }

    private void showBrushDialog() {
        String[] tools = {
            "🖌 Кисть", "🧼 Ластик", "🔲 Квадрат",
            "⭕ Круг", "↗ Стрелка",
            "🎨 Цвет кисти", "📏 Толщина", "🗑 Очистить", "✅ Выход"
        };
        new AlertDialog.Builder(this)
            .setTitle("Инструменты рисования")
            .setItems(tools, (d, i) -> {
                if (i <= 4) drawingView.setMode(DrawingView.Mode.values()[i]);
                else if (i == 5) showColorPickerForBrush();
                else if (i == 6) showStrokeWidthSeekBar();
                else if (i == 7) confirmClearAll();
                else exitDrawMode();
            }).show();
    }

    private void showStrokeWidthSeekBar() {
        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(150);
        seekBar.setProgress(10);
        seekBar.setPadding(60, 50, 60, 50);
        new AlertDialog.Builder(this)
            .setTitle("Толщина кисти")
            .setView(seekBar)
            .setPositiveButton("Готово", (d, w) -> {
                drawingView.setStrokeWidth(seekBar.getProgress());
                showBrushDialog();
            }).show();
    }

    private void confirmClearAll() {
        new AlertDialog.Builder(this)
            .setTitle("Очистить холст?")
            .setPositiveButton("Да", (d, w) -> drawingView.clearCanvas())
            .setNegativeButton("Отмена", null)
            .show();
    }

    private void showColorPickerForBrush() {
        int[] colors = {
            Color.BLACK, Color.RED, Color.BLUE, Color.GREEN,
            Color.YELLOW, Color.MAGENTA, Color.WHITE,
            Color.parseColor("#FF6D00"), Color.parseColor("#00695C")
        };
        String[] names = {
            "Чёрный", "Красный", "Синий", "Зелёный",
            "Жёлтый", "Фиолетовый", "Белый",
            "Оранжевый", "Тёмно-зелёный"
        };
        new AlertDialog.Builder(this)
            .setTitle("Цвет кисти")
            .setItems(names, (d, i) -> {
                drawingView.setStrokeColor(colors[i]);
                drawingView.setMode(DrawingView.Mode.PEN);
            }).show();
    }

    // ══════════════════════════════════════════════════════════
    //  МЕДИА (изображения)
    // ══════════════════════════════════════════════════════════
    private void showMediaDialog() {
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("image/*");
        startActivityForResult(pick, REQUEST_PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null && requestCode == REQUEST_PICK_IMAGE) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
            long id = ensureNoteId();
            String existing = prefs.getString("media_img_" + id, "");
            prefs.edit().putString("media_img_" + id,
                existing.isEmpty() ? uri.toString() : existing + "|" + uri).apply();
            addFloatingImage(uri, 60f, 180f);
        }
    }

    private void addFloatingImage(Uri uri, float startX, float startY) {
        int dp = (int) getResources().getDisplayMetrics().density;
        FrameLayout card = new FrameLayout(this);
        int size = 220 * dp;
        card.setLayoutParams(new FrameLayout.LayoutParams(size, size));
        card.setX(startX);
        card.setY(startY);
        card.setElevation(12);

        ImageView iv = new ImageView(this);
        iv.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setImageURI(uri);

        TextView del = new TextView(this);
        del.setText("✕");
        del.setTextSize(18);
        del.setTextColor(Color.WHITE);
        del.setBackgroundColor(Color.parseColor("#CC000000"));
        del.setPadding(12, 4, 12, 4);
        del.setLayoutParams(new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END));
        del.setOnClickListener(v -> floatingLayer.removeView(card));

        card.addView(iv);
        card.addView(del);
        attachDragAndZoom(card);
        floatingLayer.addView(card);
    }

    private void attachDragAndZoom(FrameLayout card) {
        final float[] scale = {1f};
        final float[] dX = new float[1], dY = new float[1];
        ScaleGestureDetector sgd = new ScaleGestureDetector(this,
            new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector d) {
                    scale[0] = Math.max(0.4f, Math.min(6f, scale[0] * d.getScaleFactor()));
                    card.setScaleX(scale[0]);
                    card.setScaleY(scale[0]);
                    return true;
                }
            });
        card.setOnTouchListener((v, e) -> {
            sgd.onTouchEvent(e);
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dX[0] = card.getX() - e.getRawX();
                    dY[0] = card.getY() - e.getRawY();
                    card.bringToFront();
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (e.getPointerCount() == 1) {
                        card.setX(e.getRawX() + dX[0]);
                        card.setY(e.getRawY() + dY[0]);
                    }
                    break;
            }
            return true;
        });
    }

    // ══════════════════════════════════════════════════════════
    //  ЗАГРУЗКА / СОХРАНЕНИЕ
    // ══════════════════════════════════════════════════════════
    private void loadNoteData() {
        editTitle.setText(prefs.getString("title_" + noteId, ""));
        editContent.setText(prefs.getString("note_" + noteId, ""));
        selectedColor = prefs.getInt("color_" + noteId, Color.WHITE);
        applyNoteColor(selectedColor);
    }

    private void restoreMediaAndDrawing() {
        File drawFile = new File(getFilesDir(), "drawing_" + noteId + ".png");
        if (drawFile.exists()) {
            Bitmap bmp = BitmapFactory.decodeFile(drawFile.getAbsolutePath());
            if (bmp != null) drawingSnapshot.setImageBitmap(bmp);
        }
        String saved = prefs.getString("media_img_" + noteId, "");
        if (!saved.isEmpty()) {
            String[] uris = saved.split("\\|");
            String[] pos = prefs.getString("media_pos_" + noteId, "").split(";");
            for (int i = 0; i < uris.length; i++) {
                if (uris[i].isEmpty()) continue;
                float x = 40f + (i % 3) * 90f, y = 140f + (i / 3) * 140f;
                if (i < pos.length && !pos[i].isEmpty()) {
                    try {
                        String[] xy = pos[i].split(",");
                        x = Float.parseFloat(xy[0]);
                        y = Float.parseFloat(xy[1]);
                    } catch (Exception ignored) {}
                }
                addFloatingImage(Uri.parse(uris[i]), x, y);
            }
        }
    }

    private void saveMediaPositions() {
        if (noteId == -1) return;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < floatingLayer.getChildCount(); i++) {
            View v = floatingLayer.getChildAt(i);
            if (v instanceof FrameLayout) {
                if (sb.length() > 0) sb.append(";");
                sb.append(v.getX()).append(",").append(v.getY());
            }
        }
        prefs.edit().putString("media_pos_" + noteId, sb.toString()).apply();
    }

    private void saveDrawingNow() {
        Bitmap bmp = null;
        if (drawingView.getVisibility() == View.VISIBLE) {
            bmp = drawingView.getBitmap();
        } else if (drawingSnapshot.getDrawable() != null) {
            bmp = ((BitmapDrawable) drawingSnapshot.getDrawable()).getBitmap();
        }
        if (bmp == null) return;
        try {
            File file = new File(getFilesDir(), "drawing_" + ensureNoteId() + ".png");
            FileOutputStream fos = new FileOutputStream(file);
            bmp.compress(Bitmap.CompressFormat.PNG, 95, fos);
            fos.close();
        } catch (Exception e) {
            Log.e(TAG, "Error saving drawing", e);
        }
    }

    private void saveNote() {
        long id = ensureNoteId();
        String date = new java.text.SimpleDateFormat(
            "dd.MM HH:mm", java.util.Locale.getDefault()
        ).format(new java.util.Date());
        prefs.edit()
            .putString("title_" + id, editTitle.getText().toString().trim())
            .putString("note_" + id, editContent.getText().toString().trim())
            .putInt("color_" + id, selectedColor)
            .putString("date_" + id, date)
            .apply();
    }

    private long ensureNoteId() {
        if (noteId == -1) {
            noteId = System.currentTimeMillis();
            String all = prefs.getString("all_ids", "");
            prefs.edit()
                .putString("all_ids",
                    all.isEmpty() ? String.valueOf(noteId) : all + "," + noteId)
                .apply();
        }
        return noteId;
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveNote();
        saveMediaPositions();
        saveDrawingNow();
        saveChecklist();
    }

    // ══════════════════════════════════════════════════════════
    //  ВНУТРЕННИЙ КЛАСС — элемент чек-листа
    // ══════════════════════════════════════════════════════════
    private static class ChecklistItem {
        String text;
        boolean checked;
        ChecklistItem(String text, boolean checked) {
            this.text    = text;
            this.checked = checked;
        }
    }
}