package com.notes.app;

public class NoteItem {
    public long id;
    public String title;
    public String content;
    public String date;
    public int color;
    public boolean isFolder = false;
    public boolean isPinned = false; // Закреплена ли заметка
    public boolean isDeleted = false; // В корзине ли она
    
    // Поля для Bubble-режима
    public float x = 0;
    public float y = 0;
    public float scale = 1.0f;
    public long parentId = -1;

    public NoteItem(long id, String title, String content, String date, int color) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.date = date;
        this.color = color;
    }
}